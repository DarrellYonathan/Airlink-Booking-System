#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <string.h>

void head()
{
	printf("\n|===========================TICKET.ID============================|");					//tampilan header
	printf("\n|                    BOOKING TICKET AIRLINK                      |");
	printf("\n|                      MORE EASY GET FUN!                        |");
	printf("\n|                                                                |");
	printf("\n|________________________________________________________________|\n");
}
