#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <string.h>

void input()
{
	for (i=0;i<1;i++)			
	{
		for(j=0;j<10;j++)
		{
			data[i][j].kursi ='A';
		}
	}
	
	for (i=1;i<2;i++)
	{
		for(j=0;j<10;j++)
		{
			data[i][j].kursi ='B';
		}
	}
	
	for (i=2;i<3;i++)
	{
		for(j=0;j<10;j++)
		{
			data[i][j].kursi ='C';
		}
	}
	
	for (i=3;i<4;i++)
	{
		for(j=0;j<10;j++)
		{
			data[i][j].kursi ='D';
		}
	}
	
	for (i=4;i<5;i++)
	{
		for(j=0;j<10;j++)
		{
			data[i][j].kursi ='E';
		}
	}

	for (i=5;i<6;i++)
	{
		for(j=0;j<10;j++)
		{
			data[i][j].kursi ='F';
		}
	}
		
	for (i=6;i<7;i++)
	{
		for(j=0;j<10;j++)
		{
			data[i][j].kursi ='G';
		}
	}
	
	for (i=7;i<8;i++)
	{
		for(j=0;j<10;j++)
		{
			data[i][j].kursi ='H';
		}
	}
	
	for (i=8;i<9;i++)
	{
		for(j=0;j<10;j++)
		{
			data[i][j].kursi ='I';
		}
	}
	
	for (i=9;i<10;i++)
	{
		for(j=0;j<10;j++)
		{
			data[i][j].kursi ='J';
		}
	}
}
